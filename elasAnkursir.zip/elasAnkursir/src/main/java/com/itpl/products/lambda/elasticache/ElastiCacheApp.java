package com.itpl.products.lambda.elasticache;

public class ElastiCacheApp {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
