package com.itpl.products.lambda.elasticache;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import redis.clients.jedis.Jedis;

public class ProductivityDuration implements RequestStreamHandler {

	@Override
	public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) throws IOException {
		Response response = new Response();
		try {
			System.out.println("Input Stream : " + inputStream);
			String request = IOUtils.toString(inputStream, "UTF-8");
			JsonObject jsonObject = new JsonParser().parse(request).getAsJsonObject();
			PivotMData pivotMData = new Gson().fromJson(jsonObject, PivotMData.class);
			Map<String, Object> returnMap = connectToRedis(pivotMData);
			response.setCode(200);
			response.setMessage("Success");
			response.setData(returnMap);
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
			e.printStackTrace();
			response.setCode(500);
			response.setMessage("Some Internal Error");
		} finally {
			String responseString = new Gson().toJson(response);
			outputStream.write(responseString.getBytes());
		}

	}

	public Map<String, Object> connectToRedis(PivotMData pivotMData) {
		Map<String, String> valueMap = new HashMap<>();
		Map<String, Object> returnMap = new HashMap<>();
		try {
			String type;
			long rowCreatedTime;
			long startTime;
			long endTime;
			long duration;
			Jedis jedis = new Jedis(System.getenv("aws_redis_endpoint"),
					Integer.parseInt(System.getenv("aws_redis_port")),
					Integer.parseInt(System.getenv("aws_redis_timeout")));
			System.out.println("aws_redis_endpoint : " + System.getenv("aws_redis_endpoint"));
			System.out.println("Is connected : " + jedis.isConnected());
			String key = pivotMData.getUserId() + "_" + pivotMData.getApplicationName();
			System.out.println("Fetching Record !!");
			valueMap = jedis.hgetAll(key);
			System.out.println("Is connected : " + jedis.isConnected());
			jedis.close();
			if (valueMap != null && !valueMap.isEmpty()) {
				type = valueMap.get("Type");
				rowCreatedTime = new Date().getTime();
				startTime = Long.parseLong(valueMap.get("StartTime"));
				endTime = Long.parseLong(valueMap.get("EndTime"));
				duration = endTime - startTime;
				returnMap.putAll(valueMap);
				returnMap.put("Type", type);
				returnMap.put("RowCreatedTime", rowCreatedTime);
				returnMap.put("Duration", duration);
				return returnMap;
			}
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
