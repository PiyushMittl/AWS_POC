package com.itpl.products.lambda.elasticache;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import redis.clients.jedis.Jedis;

public class ElastiCacheConnect implements RequestStreamHandler {

	@Override
	public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) throws IOException {
		Response response = new Response();
		try {
			System.out.println("Input Stream : " + inputStream);
			String request = IOUtils.toString(inputStream, "UTF-8");
			JsonObject jsonObject = new JsonParser().parse(request).getAsJsonObject();
			PivotMData pivotMData = new Gson().fromJson(jsonObject, PivotMData.class);
			Map<String, String> r = connectToRedis(pivotMData);
			response.setCode(200);
			response.setMessage("Success");
			response.setData(r);
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
			e.printStackTrace();
			response.setCode(500);
			response.setMessage("Some Internal Error");
		} finally {
			String responseString = new Gson().toJson(response);
			outputStream.write(responseString.getBytes());
		}

	}

	public Map<String, String> connectToRedis(PivotMData pivotMData) {
		Map<String, String> valueMap1 = new HashMap<>();
		try {
			Jedis jedis = new Jedis(System.getenv("aws_redis_endpoint"), 6379, 5000);
			System.out.println("aws_redis_endpoint : " + System.getenv("aws_redis_endpoint"));
			System.out.println("Is connected : " + jedis.isConnected());
			// if (!jedis.isConnected()) {
			// valueMap1.put("connection", "n");
			// return valueMap1;
			// }
			String key = pivotMData.getUserId() + "_" + pivotMData.getApplicationName();
			valueMap1.put("key", key);
			Map<String, String> valueMap = new HashMap<>();
			valueMap.put("StartTime", String.valueOf(pivotMData.getStartTime()));
			valueMap.put("EndTime", String.valueOf(pivotMData.getEndTime()));
			valueMap.put("Type", pivotMData.getType());
			jedis.hmset(key, valueMap);
			System.out.println("Fetching Record !!");
			valueMap1 = jedis.hgetAll(key);
			System.out.println("Is connected : " + jedis.isConnected());
			jedis.close();
			if (valueMap1 != null && !valueMap1.isEmpty()) {
				return valueMap1;
			}
		} catch (Exception e) {
			System.out.println("Exception Occurred : " + e.getMessage());
			e.printStackTrace();
		}
		return valueMap1;
	}

}
